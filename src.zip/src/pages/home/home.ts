import { Component } from '@angular/core';
import { NavController ,AlertController} from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

  export class HomePage {
  data:any
  textBoxContent: String;
  textAreaContent: String;

  constructor(private nav: NavController, private alrt: AlertController) {
    console.log("Executing Constructor..");
    this.data = {};
  }

  getAlert() {
    let textBoxContent = this.data.textBoxContent;
    let textAreaContent = this.data.textAreaContent;
    
    let alert = this.alrt.create({
      subTitle: textBoxContent + textAreaContent,
      buttons: ['OK']
    });
    alert.present();
  }


}
